package coe.java.demos.c7;

public class TwoDimArrays1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] a = {{1,0,12,-1}, {7,-3,2,5}, {-5,-2,2,9}};
		System.out.print(a[2][1]);
	}

}
