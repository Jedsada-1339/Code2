package coe.java.demos.c8;

public class ExceptionDemo1 {
	public static void main(String[] args) {
		System.out.println("Hello " + args[0]);	
	}
}
