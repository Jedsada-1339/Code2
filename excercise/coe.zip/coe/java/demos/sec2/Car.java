package coe.java.demos.sec2;

// class Car is a subclass of class 
// Vehicle
public class Car extends Vehicle {
	private int numOfDoors;
	public int getNumOfDoors() {
		return numOfDoors;
	}
	public void setNumOfDoors(int nDoors) {
		numOfDoors = nDoors;
	}
}
