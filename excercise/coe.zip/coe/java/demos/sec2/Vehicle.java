package coe.java.demos.sec2;

public class Vehicle {
	// instance variable velocity
	// non-static variable velocity
	private double velocity;
	public double getVelocity() {
		return velocity;
	}
	public void setVelocity(double v) {
		velocity = v;
	}
}
