package coe.java.demos.c2;
public class Greetings {
	public static void main(String[] args) {
		String name = "Chanapat";
		String university = "Grandma University";
		System.out.println("Hello my name is " + name + ".  Now I study at " + university + ".");
	}
}
