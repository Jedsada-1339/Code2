package coe.java.demos.c2;
public class NumberLiteralsDemo {
	public static void main(String[] args) {
		int i = 34;
		long l = 100000; 
		float f = 100.2f;   
		double d = 100.2d;
		int octal = 035; 
		int hex = 0xa2;
		System.out.println(i + " " + l + " " + f);
		System.out.println(d + " " + octal + " " + hex);
		}
}
