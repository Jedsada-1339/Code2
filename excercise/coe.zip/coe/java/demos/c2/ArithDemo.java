package coe.java.demos.c2;

public class ArithDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(5/2);
		System.out.println(5.0/2);
		System.out.println(2/4);
		System.out.println(5%2);
	}

}
