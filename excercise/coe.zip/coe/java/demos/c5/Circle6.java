package coe.java.demos.c5;

public class Circle6 {
	protected double radius = 1.0;
	
	// Getter method to read a private variable
	public double getRadius() {
		return radius;
	}
	
	// Setter method to write a private variable
	public void setRadius(double newRadius) {
		radius = newRadius;
	}
}

