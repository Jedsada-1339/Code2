class Circle3 {
    double radius;
}

public class TestCircle3 {
    public static void main(String[] args) {
        Circle3 c3 = new Circle3();
        c3.radius = 5;
        System.out.println(c3.radius);
    }
}