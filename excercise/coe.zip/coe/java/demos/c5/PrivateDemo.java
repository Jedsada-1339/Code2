package coe.java.demos.c5;

// It's a class in the same package
public class PrivateDemo {

	public static void main(String[] args) {
		Circle6 c;  // declare object
		c = new Circle6(); // create object
		c.setRadius(2.0);
	}

}
