package coe.java.demos.c5;

public class TestRectangle {
	public static void main(String[] args) {
		Rectangle2 r = new Rectangle2();
		double w = 2, h = 3;
		Rectangle2 r2 = new Rectangle2(w,h);
		Circle c = new Circle();
	}

}
