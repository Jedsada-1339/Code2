package coe.java.demos.c5;

public class TestBook2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book b = new Book("XML");
		b.setTitle("XML and Web Services");
	}

}
