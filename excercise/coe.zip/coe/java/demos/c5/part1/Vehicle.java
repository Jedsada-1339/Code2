package coe.java.demos.c5.part1;

public class Vehicle {
	// instance variable for velocity
	private double velocity;
	// instance methods for 
	// getting and setting velocity
	public void setVelocity(double v) {
		velocity = v;
	}
	public double getVelocity() {
		return velocity;
	}
}
