package coe.java.demos.c5.part1;

public class Motorcycle extends Vehicle {
	private boolean hasBasket;
}
