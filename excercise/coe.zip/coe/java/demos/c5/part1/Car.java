package coe.java.demos.c5.part1;

// Car is a subclass of Vehicle
public class Car extends Vehicle {
	// number of doors variable
	private int numOfDoors;
	public int getNumOfDoors() {
		return numOfDoors;
	}
	public void setNumOfDoors(int nDoors) {
		numOfDoors = nDoors;
	}
}
