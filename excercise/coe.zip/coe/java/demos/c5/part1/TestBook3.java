package coe.java.demos.c5.part1;

public class TestBook3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		coe.java.demos.c5.Book b = 
			new coe.java.demos.c5.Book("Android");
	}

}
