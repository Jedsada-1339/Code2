package coe.java.demos.c5;

//declared as default 
//access modifer is default
//only class in the same package
//can access this class
public class Rectangle2 {
	private double width;
	private double height;
	public Rectangle2() {
		
	}
	Rectangle2(double w, double h) {
		width = w;
		height = h;
	}
}
