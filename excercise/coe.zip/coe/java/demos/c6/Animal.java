package coe.java.demos.c6;

public class Animal {
	private String name;
	// a constructor that accepts a string
	public Animal(String name) {
		this.name = name;
	}
}
