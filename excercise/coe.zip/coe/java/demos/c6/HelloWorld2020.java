import javax.swing.JOptionPane;
public class HelloWorld2020 {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello World");
    }
}