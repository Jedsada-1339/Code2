package coe.java.demos.c6;

public class TestStudent2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student2 s = new Student2("Manee");
		s.name = "Mana";
	}

}
