package coe.java.demos.c6;
import javax.swing.JOptionPane;

public class HelloWorldGUI1 {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog( null, 
				"Hello World!" );
	}
}
