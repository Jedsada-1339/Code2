package coe.java.demos.c6;

public class TestStudent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Student s1 = new Student("Manee");
		s1.name = "Mana";
	}

}
