package coe.java.demos.c6.events;
import java.awt.event.MouseListener;

public class MouseListener1 implements 
        MouseListener {

            @Override
            public 
        }