package coe.java.demos.c6;

class Dhamma {
	public void thinkPositive() {}
}
public class Goodness extends Dhamma  {
	
}
