package coe.java.demos.c6.y2020;
import java.awt.event.*;
class ButtonListener implements ActionListener {

    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        System.exit(0);
    }
}